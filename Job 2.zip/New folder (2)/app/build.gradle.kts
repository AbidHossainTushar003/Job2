plugins {
    alias(libs.plugins.android.application)
    id("com.google.devtools.ksp")
}

android {
    namespace = "com.example.job2"
    compileSdk = 34

    buildFeatures {
        viewBinding = true
    }

    defaultConfig {
        applicationId = "com.example.job2"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }
}

dependencies {
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.appcompat)
    implementation(libs.material)
    implementation(libs.androidx.constraintlayout)
    implementation(libs.androidx.activity.ktx)
    testImplementation(libs.junit)
    androidTestImplementation(libs.androidx.junit)
    androidTestImplementation(libs.androidx.espresso.core)


    val roomVersion = "2.8.0" // Use the latest stable version

    // Core Room Runtime components
    implementation("androidx.room:room-runtime:$roomVersion")

    // Kotlin Extensions and Coroutines support for Room
    implementation("androidx.room:room-ktx:$roomVersion")

    // KSP code generator for Room annotations
    ksp("androidx.room:room-compiler:$roomVersion")

    val lifecycleVersion = "2.8.4" // Use the latest stable version

    // LiveData support
    implementation("androidx.lifecycle:lifecycle-livedata-ktx:$lifecycleVersion")

    // Lifecycle utilities for Coroutines (provides lifecycleScope and repeatOnLifecycle)
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:$lifecycleVersion")

    // ViewModel utilities (provides viewModelScope)
    implementation("androidx.lifecycle:lifecycle-viewmodel-ktx:$lifecycleVersion")
}

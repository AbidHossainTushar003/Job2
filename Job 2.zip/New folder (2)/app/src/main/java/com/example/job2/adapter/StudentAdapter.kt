package com.example.job2.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.job2.data.Student
import com.example.job2.databinding.ItemStudentBinding

class StudentAdapter(
    private val onEditClick: (Student) -> Unit,
    private val onDeleteClick: (Student) -> Unit): RecyclerView.Adapter<StudentAdapter.StudentViewHolder>() {

    private var studentList = emptyList<Student>()

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): StudentViewHolder {
        val binding = ItemStudentBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return StudentViewHolder(binding)
    }

    override fun onBindViewHolder(
        holder: StudentViewHolder,
        position: Int
    ) {
        val student = studentList[position]
        holder.bind(student)
    }
    fun submitList(list: List<Student>) {
        studentList = list
        notifyDataSetChanged()
    }

    override fun getItemCount(): Int = studentList.size

    inner class StudentViewHolder(val binding: ItemStudentBinding) : RecyclerView.ViewHolder(binding.root){

        fun bind(student: Student){

            binding.txtName.text = student.name
            binding.txtEmail.text = student.email

            binding.btnEdit.setOnClickListener {
                onEditClick(student)
            }
            binding.btnDelete.setOnClickListener {
                onDeleteClick(student)
            }

        }
    }
}
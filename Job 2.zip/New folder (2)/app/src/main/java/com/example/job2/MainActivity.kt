package com.example.job2

import android.annotation.SuppressLint
import android.os.Bundle
import android.widget.PopupMenu
import android.widget.Toast

import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SearchView
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager

import com.example.job2.adapter.StudentAdapter
import com.example.job2.data.Student
import com.example.job2.data.StudentDatabase
import com.example.job2.databinding.ActivityMainBinding
import com.example.job2.databinding.DialogAddEditBinding
import com.example.job2.repo.StudentRepository
import com.example.job2.viewModel.StudentViewModel
import com.example.job2.viewModel.StudentViewModelFactory

import com.google.android.material.dialog.MaterialAlertDialogBuilder

import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.launch


class MainActivity : AppCompatActivity() {


    private lateinit var binding: ActivityMainBinding

    private lateinit var viewModel: StudentViewModel

    private lateinit var adapter: StudentAdapter


    private var searchJob: Job? = null

    private var collectJob: Job? = null



    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)

        enableEdgeToEdge()


        binding = ActivityMainBinding.inflate(layoutInflater)

        setContentView(binding.root)



        // Room Database

        val dao = StudentDatabase
            .getDatabase(this)
            .studentDao()


        val repository = StudentRepository(dao)


        viewModel = ViewModelProvider(
            this,
            StudentViewModelFactory(repository)
        )[StudentViewModel::class.java]





        // RecyclerView Adapter

        adapter = StudentAdapter(

            onEditClick = { student ->

                showStudentDialog(student)

            },


            onDeleteClick = { student ->


                viewModel.delete(student)


                Toast.makeText(
                    this,
                    "Student deleted",
                    Toast.LENGTH_SHORT
                ).show()

            }

        )



        binding.recyclerView.apply {

            layoutManager = LinearLayoutManager(this@MainActivity)

            adapter = this@MainActivity.adapter

            setHasFixedSize(true)

        }





        // Search

        searchQuery()





        // Filter Menu

        binding.btnFilter.setOnClickListener {


            PopupMenu(
                this,
                binding.btnFilter
            ).apply {


                menu.add("A-Z")

                menu.add("Z-A")

                menu.add("Latest")

                menu.add("Oldest")



                setOnMenuItemClickListener { item ->


                    when(item.title){


                        "A-Z" -> {

                            collectStudents(
                                viewModel.getStudentsByNameAsc()
                            )

                        }


                        "Z-A" -> {

                            collectStudents(
                                viewModel.getStudentsByNameDesc()
                            )

                        }


                        "Latest" -> {

                            collectStudents(
                                viewModel.allStudents
                            )

                        }


                        "Oldest" -> {

                            collectStudents(
                                viewModel.getStudentsOldest()
                            )

                        }

                    }


                    true

                }


                show()

            }


        }





        // Default Student List

        collectStudents(viewModel.allStudents)





        // Add Student

        binding.fabAdd.setOnClickListener {


            showStudentDialog(null)


        }


    }






    private fun searchQuery(){


        binding.searchView.setOnQueryTextListener(

            object : SearchView.OnQueryTextListener {


                override fun onQueryTextSubmit(
                    query: String?
                ): Boolean {

                    return false

                }




                override fun onQueryTextChange(
                    newText: String?
                ): Boolean {


                    searchJob?.cancel()



                    searchJob = lifecycleScope.launch {


                        viewModel
                            .searchStudents(
                                newText ?: ""
                            )
                            .collect { students ->


                                adapter.submitList(students)


                            }


                    }


                    return true

                }


            }

        )


    }








    @SuppressLint("SetTextI18n")
    private fun showStudentDialog(
        student: Student?
    ){


        val dialogBinding =
            DialogAddEditBinding.inflate(layoutInflater)



        if(student != null){


            dialogBinding.txtTitle.text =
                "Update Student"


            dialogBinding.btnSave.text =
                "Update"



            dialogBinding.etName.setText(
                student.name
            )


            dialogBinding.etEmail.setText(
                student.email
            )


        }






        val dialog =
            MaterialAlertDialogBuilder(this)
                .setView(dialogBinding.root)
                .create()



        dialog.show()






        dialogBinding.btnSave.setOnClickListener {



            val name =
                dialogBinding.etName.text
                    .toString()
                    .trim()



            val email =
                dialogBinding.etEmail.text
                    .toString()
                    .trim()





            if(name.isEmpty() || email.isEmpty()){


                Toast.makeText(
                    this,
                    "Please fill all fields",
                    Toast.LENGTH_SHORT
                ).show()


                return@setOnClickListener

            }






            if(student == null){



                viewModel.insert(

                    Student(
                        name = name,
                        email = email
                    )

                )



                Toast.makeText(
                    this,
                    "Student saved",
                    Toast.LENGTH_SHORT
                ).show()



            }
            else {



                viewModel.update(

                    Student(

                        id = student.id,

                        name = name,

                        email = email

                    )

                )



                Toast.makeText(
                    this,
                    "Student updated",
                    Toast.LENGTH_SHORT
                ).show()



            }





            dialog.dismiss()



        }


    }








    private fun collectStudents(
        flow: Flow<List<Student>>
    ){



        collectJob?.cancel()



        collectJob = lifecycleScope.launch {



            flow.collect { students ->


                adapter.submitList(students)


            }


        }



    }





    override fun onDestroy() {


        super.onDestroy()


        searchJob?.cancel()

        collectJob?.cancel()


    }


}
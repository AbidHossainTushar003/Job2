package com.example.job2.viewModel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.job2.data.Student
import com.example.job2.repo.StudentRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.launch

class StudentViewModel (private val repository: StudentRepository) : ViewModel() {

    val allStudents : Flow<List<Student>> =repository.allStudents

    fun insert(student: Student){
        viewModelScope.launch {
            repository.insert(student)
        }
    }
    fun update(student: Student){
        viewModelScope.launch {
            repository.update(student)
        }
    }
    fun delete(student: Student){
        viewModelScope.launch {
            repository.delete(student)
        }
    }
    fun searchStudents(search: String): Flow<List<Student>> {
        return repository.searchStudents(search)
    }
    fun getStudentsByNameAsc() = repository.getStudentsByNameAsc()

    fun getStudentsByNameDesc() = repository.getStudentsByNameDesc()

    fun getStudentsOldest() =
        repository.getStudentsOldest()


}
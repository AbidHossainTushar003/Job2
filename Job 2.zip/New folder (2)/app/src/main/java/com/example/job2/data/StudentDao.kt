package com.example.job2.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow


@Dao
interface StudentDao {


    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStudent(student: Student)

    @Update
    suspend fun updateStudent(student: Student)

    @Delete
    suspend fun deleteStudent(student: Student)


    @Query("select * from student_table order by id asc")
    fun getAllStudents(): Flow<List<Student>>

    @Query("""select * from student_table 
         where name like '%' || :search || '%'
         or email like '%' || :search || '%'
         order by id desc
     """)
    fun searchStudents(search: String): Flow<List<Student>>

    @Query("SELECT * FROM student_table ORDER BY name ASC")
    fun getStudentsByNameAsc(): Flow<List<Student>>

    @Query("SELECT * FROM student_table ORDER BY name DESC")
    fun getStudentsByNameDesc(): Flow<List<Student>>

    @Query("SELECT * FROM student_table ORDER BY id ASC")
    fun getStudentsOldest(): Flow<List<Student>>
}
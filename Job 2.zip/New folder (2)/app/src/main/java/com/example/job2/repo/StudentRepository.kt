package com.example.job2.repo

import com.example.job2.data.Student
import com.example.job2.data.StudentDao
import kotlinx.coroutines.flow.Flow

class StudentRepository(private val studentDao: StudentDao) {



    val allStudents : Flow<List<Student>> =studentDao.getAllStudents()

    suspend fun insert(student: Student){
        studentDao.insertStudent(student)
    }
    suspend fun update(student: Student){
        studentDao.updateStudent(student)
    }
    suspend fun delete(student: Student){
        studentDao.deleteStudent(student)
    }

    fun searchStudents(search: String): Flow<List<Student>> {
        return studentDao.searchStudents(search)
    }
    fun getStudentsByNameAsc() = studentDao.getStudentsByNameAsc()

    fun getStudentsByNameDesc() = studentDao.getStudentsByNameDesc()

}